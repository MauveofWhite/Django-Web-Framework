# detail how to build and install the app.

from setuptools import setup

setup()
